public class Permutation {
  public static void main(String[] args) {
    RandomizedQueue<String> rq = new RandomizedQueue<>();
  }
}
